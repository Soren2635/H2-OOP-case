﻿namespace H2_OOP_case_projekt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateUser = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CReateUserButtonCreateUser = new System.Windows.Forms.Button();
            this.DatoTextboxCreateUser = new System.Windows.Forms.TextBox();
            this.DatoLabelCreateUser = new System.Windows.Forms.Label();
            this.PostNrTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.PostNrLabelCreateUser = new System.Windows.Forms.Label();
            this.AdresseTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.AdresseLabelCreateUser = new System.Windows.Forms.Label();
            this.EfternavnTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.EfterNavnLabelCreateUser = new System.Windows.Forms.Label();
            this.FornavnTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.FornavnLabelCreateUser = new System.Windows.Forms.Label();
            this.DeleteUser = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DeleteUserButtonDeleteUser = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UserIdTextBoxDeleteUser = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CreateUser
            // 
            this.CreateUser.Location = new System.Drawing.Point(467, 12);
            this.CreateUser.Name = "CreateUser";
            this.CreateUser.Size = new System.Drawing.Size(108, 49);
            this.CreateUser.TabIndex = 1;
            this.CreateUser.Text = "Create user";
            this.CreateUser.UseVisualStyleBackColor = true;
            this.CreateUser.Click += new System.EventHandler(this.CreateUser_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CReateUserButtonCreateUser);
            this.panel1.Controls.Add(this.DatoTextboxCreateUser);
            this.panel1.Controls.Add(this.DatoLabelCreateUser);
            this.panel1.Controls.Add(this.PostNrTextBoxCreateUser);
            this.panel1.Controls.Add(this.PostNrLabelCreateUser);
            this.panel1.Controls.Add(this.AdresseTextBoxCreateUser);
            this.panel1.Controls.Add(this.AdresseLabelCreateUser);
            this.panel1.Controls.Add(this.EfternavnTextBoxCreateUser);
            this.panel1.Controls.Add(this.EfterNavnLabelCreateUser);
            this.panel1.Controls.Add(this.FornavnTextBoxCreateUser);
            this.panel1.Controls.Add(this.FornavnLabelCreateUser);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(382, 388);
            this.panel1.TabIndex = 2;
            // 
            // CReateUserButtonCreateUser
            // 
            this.CReateUserButtonCreateUser.Location = new System.Drawing.Point(136, 329);
            this.CReateUserButtonCreateUser.Name = "CReateUserButtonCreateUser";
            this.CReateUserButtonCreateUser.Size = new System.Drawing.Size(101, 37);
            this.CReateUserButtonCreateUser.TabIndex = 11;
            this.CReateUserButtonCreateUser.Text = "Create User";
            this.CReateUserButtonCreateUser.UseVisualStyleBackColor = true;
            this.CReateUserButtonCreateUser.Click += new System.EventHandler(this.CReateUserButtonCreateUser_Click);
            // 
            // DatoTextboxCreateUser
            // 
            this.DatoTextboxCreateUser.Location = new System.Drawing.Point(39, 275);
            this.DatoTextboxCreateUser.Name = "DatoTextboxCreateUser";
            this.DatoTextboxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.DatoTextboxCreateUser.TabIndex = 10;
            // 
            // DatoLabelCreateUser
            // 
            this.DatoLabelCreateUser.AutoSize = true;
            this.DatoLabelCreateUser.Location = new System.Drawing.Point(36, 241);
            this.DatoLabelCreateUser.Name = "DatoLabelCreateUser";
            this.DatoLabelCreateUser.Size = new System.Drawing.Size(38, 17);
            this.DatoLabelCreateUser.TabIndex = 9;
            this.DatoLabelCreateUser.Text = "Dato";
            // 
            // PostNrTextBoxCreateUser
            // 
            this.PostNrTextBoxCreateUser.Location = new System.Drawing.Point(220, 194);
            this.PostNrTextBoxCreateUser.Name = "PostNrTextBoxCreateUser";
            this.PostNrTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.PostNrTextBoxCreateUser.TabIndex = 8;
            // 
            // PostNrLabelCreateUser
            // 
            this.PostNrLabelCreateUser.AutoSize = true;
            this.PostNrLabelCreateUser.Location = new System.Drawing.Point(217, 160);
            this.PostNrLabelCreateUser.Name = "PostNrLabelCreateUser";
            this.PostNrLabelCreateUser.Size = new System.Drawing.Size(51, 17);
            this.PostNrLabelCreateUser.TabIndex = 7;
            this.PostNrLabelCreateUser.Text = "PostNr";
            // 
            // AdresseTextBoxCreateUser
            // 
            this.AdresseTextBoxCreateUser.Location = new System.Drawing.Point(39, 194);
            this.AdresseTextBoxCreateUser.Name = "AdresseTextBoxCreateUser";
            this.AdresseTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.AdresseTextBoxCreateUser.TabIndex = 6;
            // 
            // AdresseLabelCreateUser
            // 
            this.AdresseLabelCreateUser.AutoSize = true;
            this.AdresseLabelCreateUser.Location = new System.Drawing.Point(36, 160);
            this.AdresseLabelCreateUser.Name = "AdresseLabelCreateUser";
            this.AdresseLabelCreateUser.Size = new System.Drawing.Size(60, 17);
            this.AdresseLabelCreateUser.TabIndex = 5;
            this.AdresseLabelCreateUser.Text = "Adresse";
            // 
            // EfternavnTextBoxCreateUser
            // 
            this.EfternavnTextBoxCreateUser.Location = new System.Drawing.Point(220, 109);
            this.EfternavnTextBoxCreateUser.Name = "EfternavnTextBoxCreateUser";
            this.EfternavnTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.EfternavnTextBoxCreateUser.TabIndex = 4;
            // 
            // EfterNavnLabelCreateUser
            // 
            this.EfterNavnLabelCreateUser.AutoSize = true;
            this.EfterNavnLabelCreateUser.Location = new System.Drawing.Point(217, 75);
            this.EfterNavnLabelCreateUser.Name = "EfterNavnLabelCreateUser";
            this.EfterNavnLabelCreateUser.Size = new System.Drawing.Size(69, 17);
            this.EfterNavnLabelCreateUser.TabIndex = 3;
            this.EfterNavnLabelCreateUser.Text = "Efternavn";
            // 
            // FornavnTextBoxCreateUser
            // 
            this.FornavnTextBoxCreateUser.Location = new System.Drawing.Point(39, 109);
            this.FornavnTextBoxCreateUser.Name = "FornavnTextBoxCreateUser";
            this.FornavnTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.FornavnTextBoxCreateUser.TabIndex = 2;
            // 
            // FornavnLabelCreateUser
            // 
            this.FornavnLabelCreateUser.AutoSize = true;
            this.FornavnLabelCreateUser.Location = new System.Drawing.Point(36, 75);
            this.FornavnLabelCreateUser.Name = "FornavnLabelCreateUser";
            this.FornavnLabelCreateUser.Size = new System.Drawing.Size(60, 17);
            this.FornavnLabelCreateUser.TabIndex = 1;
            this.FornavnLabelCreateUser.Text = "Fornavn";
            // 
            // DeleteUser
            // 
            this.DeleteUser.Location = new System.Drawing.Point(592, 13);
            this.DeleteUser.Name = "DeleteUser";
            this.DeleteUser.Size = new System.Drawing.Size(100, 48);
            this.DeleteUser.TabIndex = 3;
            this.DeleteUser.Text = "Delete user";
            this.DeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUser.Click += new System.EventHandler(this.DeleteUser_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.UserIdTextBoxDeleteUser);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.DeleteUserButtonDeleteUser);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(382, 388);
            this.panel2.TabIndex = 4;
            // 
            // DeleteUserButtonDeleteUser
            // 
            this.DeleteUserButtonDeleteUser.Location = new System.Drawing.Point(184, 46);
            this.DeleteUserButtonDeleteUser.Name = "DeleteUserButtonDeleteUser";
            this.DeleteUserButtonDeleteUser.Size = new System.Drawing.Size(102, 27);
            this.DeleteUserButtonDeleteUser.TabIndex = 0;
            this.DeleteUserButtonDeleteUser.Text = "Delete User";
            this.DeleteUserButtonDeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUserButtonDeleteUser.Click += new System.EventHandler(this.DeleteUserButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "User id";
            // 
            // UserIdTextBoxDeleteUser
            // 
            this.UserIdTextBoxDeleteUser.Location = new System.Drawing.Point(42, 51);
            this.UserIdTextBoxDeleteUser.Name = "UserIdTextBoxDeleteUser";
            this.UserIdTextBoxDeleteUser.Size = new System.Drawing.Size(100, 22);
            this.UserIdTextBoxDeleteUser.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 591);
            this.Controls.Add(this.DeleteUser);
            this.Controls.Add(this.CreateUser);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CreateUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox EfternavnTextBoxCreateUser;
        private System.Windows.Forms.Label EfterNavnLabelCreateUser;
        private System.Windows.Forms.TextBox FornavnTextBoxCreateUser;
        private System.Windows.Forms.Label FornavnLabelCreateUser;
        private System.Windows.Forms.TextBox PostNrTextBoxCreateUser;
        private System.Windows.Forms.Label PostNrLabelCreateUser;
        private System.Windows.Forms.TextBox AdresseTextBoxCreateUser;
        private System.Windows.Forms.Label AdresseLabelCreateUser;
        private System.Windows.Forms.Button CReateUserButtonCreateUser;
        private System.Windows.Forms.TextBox DatoTextboxCreateUser;
        private System.Windows.Forms.Label DatoLabelCreateUser;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button DeleteUserButtonDeleteUser;
        private System.Windows.Forms.Button DeleteUser;
        private System.Windows.Forms.TextBox UserIdTextBoxDeleteUser;
        private System.Windows.Forms.Label label1;
    }
}

