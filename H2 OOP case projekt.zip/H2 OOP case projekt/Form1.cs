﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H2_OOP_case_projekt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Form form1 = new Form();
            //form1.FormBorderStyle = FormBorderStyle.Sizable;

            panel1.Visible = false;
            panel2.Visible = false;
            
        }
        private void CreateUser_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }
        private void DeleteUser_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }






        private void CReateUserButtonCreateUser_Click(object sender, EventArgs e)
        {
            string Fornavn, Efternavn, Adresse, PostNr, Dato;
            
            Fornavn     = FornavnTextBoxCreateUser.Text;
            Efternavn   = EfternavnTextBoxCreateUser.Text;
            Adresse     = AdresseTextBoxCreateUser.Text;
            PostNr      = PostNrTextBoxCreateUser.Text;
            Dato        = DatoTextboxCreateUser.Text;
            
        }

        private void DeleteUserButton_Click(object sender, EventArgs e)
        {

        }

        
    }
}
