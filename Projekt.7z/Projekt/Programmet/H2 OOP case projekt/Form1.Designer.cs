﻿namespace H2_OOP_case_projekt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateUser = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CReateUserButtonCreateUser = new System.Windows.Forms.Button();
            this.DatoTextboxCreateUser = new System.Windows.Forms.TextBox();
            this.DatoLabelCreateUser = new System.Windows.Forms.Label();
            this.PostNrTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.PostNrLabelCreateUser = new System.Windows.Forms.Label();
            this.AdresseTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.AdresseLabelCreateUser = new System.Windows.Forms.Label();
            this.EfternavnTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.EfterNavnLabelCreateUser = new System.Windows.Forms.Label();
            this.FornavnTextBoxCreateUser = new System.Windows.Forms.TextBox();
            this.FornavnLabelCreateUser = new System.Windows.Forms.Label();
            this.DeleteUser = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GenopretButtonDeleteUser = new System.Windows.Forms.Button();
            this.UserIdTextBoxDeleteUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DeleteUserButtonDeleteUser = new System.Windows.Forms.Button();
            this.CreateKontoPanel = new System.Windows.Forms.Panel();
            this.OpretKontoButton = new System.Windows.Forms.Button();
            this.DatoiTextBoxCreateKonto = new System.Windows.Forms.TextBox();
            this.SaldoTextBoxCreateKonto = new System.Windows.Forms.TextBox();
            this.KontoTypeIDTextBoxCreateKonto = new System.Windows.Forms.TextBox();
            this.KundeNrTextBoxCreateKonto = new System.Windows.Forms.TextBox();
            this.DatoCreateKonto = new System.Windows.Forms.Label();
            this.SaldoCreateKonto = new System.Windows.Forms.Label();
            this.KontoTypeIdCreateKonto = new System.Windows.Forms.Label();
            this.KundeNrCreateKonto = new System.Windows.Forms.Label();
            this.CreateKonto = new System.Windows.Forms.Button();
            this.SelectKunde = new System.Windows.Forms.Button();
            this.SelectKontoPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.FuldlisteFindKontoKnap = new System.Windows.Forms.Button();
            this.FindKundeButton = new System.Windows.Forms.Button();
            this.KundeNrSelectKontoKundeNr = new System.Windows.Forms.Label();
            this.SelectKontoTextBoxSelectKonto = new System.Windows.Forms.TextBox();
            this.SletKontoKnap = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.KontoNrGenopret = new System.Windows.Forms.Button();
            this.KontoNrSlet = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.KontoNrTextBox = new System.Windows.Forms.TextBox();
            this.PosteringMenu = new System.Windows.Forms.Button();
            this.PosteringMenuPanel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.PosteringsDecimalDecimal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PosteringsDato = new System.Windows.Forms.TextBox();
            this.PosteringMenuAccepterKnap = new System.Windows.Forms.Button();
            this.PosteringMenuLabelBeløb = new System.Windows.Forms.Label();
            this.PosteringIntInt = new System.Windows.Forms.TextBox();
            this.SelectKonto = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.FindKontoFuldListeKnap = new System.Windows.Forms.Button();
            this.FindKontoFindKnap = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.FindKontoKontoNr = new System.Windows.Forms.TextBox();
            this.FindTransaktionButton = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.TransaktionsFindKnap = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TransaktionTextBox = new System.Windows.Forms.TextBox();
            this.UpdateKundeKnap = new System.Windows.Forms.Button();
            this.UpdateKontoKnap = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.UpdateKundeKundeNr = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.UpdateKundeOk = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.UpdateKundLabelPostNr = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.UpdateKundeLabelEfternavn = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.UpdateKundeDato = new System.Windows.Forms.TextBox();
            this.UpdateKundePostNr = new System.Windows.Forms.TextBox();
            this.UpdateKundeAdresse = new System.Windows.Forms.TextBox();
            this.UpdateKundeEfternavn = new System.Windows.Forms.TextBox();
            this.UpdateKundeFornavn = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.UpdateKontoOk = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.UpdateKontoSaldo = new System.Windows.Forms.TextBox();
            this.UpdateKontoOprettelsesdato = new System.Windows.Forms.TextBox();
            this.UpdateKontoAktiv = new System.Windows.Forms.TextBox();
            this.UpdateKontoNr = new System.Windows.Forms.TextBox();
            this.UpdateKontypeKnap = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.UpdateKontoTypeRentesats = new System.Windows.Forms.TextBox();
            this.UpdateKontotypeKontotype = new System.Windows.Forms.ComboBox();
            this.UpdateKontotypeOk = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.CreateKontoPanel.SuspendLayout();
            this.SelectKontoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.PosteringMenuPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // CreateUser
            // 
            this.CreateUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.CreateUser.Location = new System.Drawing.Point(12, 12);
            this.CreateUser.Name = "CreateUser";
            this.CreateUser.Size = new System.Drawing.Size(108, 54);
            this.CreateUser.TabIndex = 1;
            this.CreateUser.Text = "Opret kunde";
            this.CreateUser.UseVisualStyleBackColor = true;
            this.CreateUser.Click += new System.EventHandler(this.CreateUser_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CReateUserButtonCreateUser);
            this.panel1.Controls.Add(this.DatoTextboxCreateUser);
            this.panel1.Controls.Add(this.DatoLabelCreateUser);
            this.panel1.Controls.Add(this.PostNrTextBoxCreateUser);
            this.panel1.Controls.Add(this.PostNrLabelCreateUser);
            this.panel1.Controls.Add(this.AdresseTextBoxCreateUser);
            this.panel1.Controls.Add(this.AdresseLabelCreateUser);
            this.panel1.Controls.Add(this.EfternavnTextBoxCreateUser);
            this.panel1.Controls.Add(this.EfterNavnLabelCreateUser);
            this.panel1.Controls.Add(this.FornavnTextBoxCreateUser);
            this.panel1.Controls.Add(this.FornavnLabelCreateUser);
            this.panel1.Location = new System.Drawing.Point(260, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 441);
            this.panel1.TabIndex = 2;
            // 
            // CReateUserButtonCreateUser
            // 
            this.CReateUserButtonCreateUser.Location = new System.Drawing.Point(136, 329);
            this.CReateUserButtonCreateUser.Name = "CReateUserButtonCreateUser";
            this.CReateUserButtonCreateUser.Size = new System.Drawing.Size(101, 37);
            this.CReateUserButtonCreateUser.TabIndex = 11;
            this.CReateUserButtonCreateUser.Text = "Ok";
            this.CReateUserButtonCreateUser.UseVisualStyleBackColor = true;
            this.CReateUserButtonCreateUser.Click += new System.EventHandler(this.CReateUserButtonCreateUser_Click);
            // 
            // DatoTextboxCreateUser
            // 
            this.DatoTextboxCreateUser.Location = new System.Drawing.Point(39, 275);
            this.DatoTextboxCreateUser.Name = "DatoTextboxCreateUser";
            this.DatoTextboxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.DatoTextboxCreateUser.TabIndex = 10;
            // 
            // DatoLabelCreateUser
            // 
            this.DatoLabelCreateUser.AutoSize = true;
            this.DatoLabelCreateUser.Location = new System.Drawing.Point(36, 241);
            this.DatoLabelCreateUser.Name = "DatoLabelCreateUser";
            this.DatoLabelCreateUser.Size = new System.Drawing.Size(38, 17);
            this.DatoLabelCreateUser.TabIndex = 9;
            this.DatoLabelCreateUser.Text = "Dato";
            // 
            // PostNrTextBoxCreateUser
            // 
            this.PostNrTextBoxCreateUser.Location = new System.Drawing.Point(220, 194);
            this.PostNrTextBoxCreateUser.Name = "PostNrTextBoxCreateUser";
            this.PostNrTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.PostNrTextBoxCreateUser.TabIndex = 8;
            // 
            // PostNrLabelCreateUser
            // 
            this.PostNrLabelCreateUser.AutoSize = true;
            this.PostNrLabelCreateUser.Location = new System.Drawing.Point(217, 160);
            this.PostNrLabelCreateUser.Name = "PostNrLabelCreateUser";
            this.PostNrLabelCreateUser.Size = new System.Drawing.Size(51, 17);
            this.PostNrLabelCreateUser.TabIndex = 7;
            this.PostNrLabelCreateUser.Text = "PostNr";
            // 
            // AdresseTextBoxCreateUser
            // 
            this.AdresseTextBoxCreateUser.Location = new System.Drawing.Point(39, 194);
            this.AdresseTextBoxCreateUser.Name = "AdresseTextBoxCreateUser";
            this.AdresseTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.AdresseTextBoxCreateUser.TabIndex = 6;
            // 
            // AdresseLabelCreateUser
            // 
            this.AdresseLabelCreateUser.AutoSize = true;
            this.AdresseLabelCreateUser.Location = new System.Drawing.Point(36, 160);
            this.AdresseLabelCreateUser.Name = "AdresseLabelCreateUser";
            this.AdresseLabelCreateUser.Size = new System.Drawing.Size(60, 17);
            this.AdresseLabelCreateUser.TabIndex = 5;
            this.AdresseLabelCreateUser.Text = "Adresse";
            // 
            // EfternavnTextBoxCreateUser
            // 
            this.EfternavnTextBoxCreateUser.Location = new System.Drawing.Point(220, 109);
            this.EfternavnTextBoxCreateUser.Name = "EfternavnTextBoxCreateUser";
            this.EfternavnTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.EfternavnTextBoxCreateUser.TabIndex = 4;
            // 
            // EfterNavnLabelCreateUser
            // 
            this.EfterNavnLabelCreateUser.AutoSize = true;
            this.EfterNavnLabelCreateUser.Location = new System.Drawing.Point(217, 75);
            this.EfterNavnLabelCreateUser.Name = "EfterNavnLabelCreateUser";
            this.EfterNavnLabelCreateUser.Size = new System.Drawing.Size(69, 17);
            this.EfterNavnLabelCreateUser.TabIndex = 3;
            this.EfterNavnLabelCreateUser.Text = "Efternavn";
            // 
            // FornavnTextBoxCreateUser
            // 
            this.FornavnTextBoxCreateUser.Location = new System.Drawing.Point(39, 109);
            this.FornavnTextBoxCreateUser.Name = "FornavnTextBoxCreateUser";
            this.FornavnTextBoxCreateUser.Size = new System.Drawing.Size(142, 22);
            this.FornavnTextBoxCreateUser.TabIndex = 2;
            // 
            // FornavnLabelCreateUser
            // 
            this.FornavnLabelCreateUser.AutoSize = true;
            this.FornavnLabelCreateUser.Location = new System.Drawing.Point(36, 75);
            this.FornavnLabelCreateUser.Name = "FornavnLabelCreateUser";
            this.FornavnLabelCreateUser.Size = new System.Drawing.Size(60, 17);
            this.FornavnLabelCreateUser.TabIndex = 1;
            this.FornavnLabelCreateUser.Text = "Fornavn";
            // 
            // DeleteUser
            // 
            this.DeleteUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.DeleteUser.Location = new System.Drawing.Point(128, 12);
            this.DeleteUser.Name = "DeleteUser";
            this.DeleteUser.Size = new System.Drawing.Size(108, 54);
            this.DeleteUser.TabIndex = 3;
            this.DeleteUser.Text = "Slet bruger/Genopret kunde";
            this.DeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUser.Click += new System.EventHandler(this.DeleteUser_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.GenopretButtonDeleteUser);
            this.panel2.Controls.Add(this.UserIdTextBoxDeleteUser);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.DeleteUserButtonDeleteUser);
            this.panel2.Location = new System.Drawing.Point(260, 20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(710, 441);
            this.panel2.TabIndex = 4;
            // 
            // GenopretButtonDeleteUser
            // 
            this.GenopretButtonDeleteUser.Location = new System.Drawing.Point(187, 64);
            this.GenopretButtonDeleteUser.Name = "GenopretButtonDeleteUser";
            this.GenopretButtonDeleteUser.Size = new System.Drawing.Size(102, 27);
            this.GenopretButtonDeleteUser.TabIndex = 3;
            this.GenopretButtonDeleteUser.Text = "Genopret";
            this.GenopretButtonDeleteUser.UseVisualStyleBackColor = true;
            this.GenopretButtonDeleteUser.Click += new System.EventHandler(this.GenopretButtonDeleteUser_Click);
            // 
            // UserIdTextBoxDeleteUser
            // 
            this.UserIdTextBoxDeleteUser.Location = new System.Drawing.Point(42, 51);
            this.UserIdTextBoxDeleteUser.Name = "UserIdTextBoxDeleteUser";
            this.UserIdTextBoxDeleteUser.Size = new System.Drawing.Size(100, 22);
            this.UserIdTextBoxDeleteUser.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "User id";
            // 
            // DeleteUserButtonDeleteUser
            // 
            this.DeleteUserButtonDeleteUser.Location = new System.Drawing.Point(187, 31);
            this.DeleteUserButtonDeleteUser.Name = "DeleteUserButtonDeleteUser";
            this.DeleteUserButtonDeleteUser.Size = new System.Drawing.Size(102, 27);
            this.DeleteUserButtonDeleteUser.TabIndex = 0;
            this.DeleteUserButtonDeleteUser.Text = "Ok";
            this.DeleteUserButtonDeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUserButtonDeleteUser.Click += new System.EventHandler(this.DeleteUserButton_Click);
            // 
            // CreateKontoPanel
            // 
            this.CreateKontoPanel.BackColor = System.Drawing.SystemColors.Control;
            this.CreateKontoPanel.Controls.Add(this.OpretKontoButton);
            this.CreateKontoPanel.Controls.Add(this.DatoiTextBoxCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.SaldoTextBoxCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.KontoTypeIDTextBoxCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.KundeNrTextBoxCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.DatoCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.SaldoCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.KontoTypeIdCreateKonto);
            this.CreateKontoPanel.Controls.Add(this.KundeNrCreateKonto);
            this.CreateKontoPanel.Location = new System.Drawing.Point(260, 20);
            this.CreateKontoPanel.Name = "CreateKontoPanel";
            this.CreateKontoPanel.Size = new System.Drawing.Size(382, 387);
            this.CreateKontoPanel.TabIndex = 6;
            // 
            // OpretKontoButton
            // 
            this.OpretKontoButton.Location = new System.Drawing.Point(39, 167);
            this.OpretKontoButton.Name = "OpretKontoButton";
            this.OpretKontoButton.Size = new System.Drawing.Size(75, 23);
            this.OpretKontoButton.TabIndex = 8;
            this.OpretKontoButton.Text = "Opret konto";
            this.OpretKontoButton.UseVisualStyleBackColor = true;
            this.OpretKontoButton.Click += new System.EventHandler(this.OpretKontoButton_Click);
            // 
            // DatoiTextBoxCreateKonto
            // 
            this.DatoiTextBoxCreateKonto.Location = new System.Drawing.Point(203, 130);
            this.DatoiTextBoxCreateKonto.Name = "DatoiTextBoxCreateKonto";
            this.DatoiTextBoxCreateKonto.Size = new System.Drawing.Size(100, 22);
            this.DatoiTextBoxCreateKonto.TabIndex = 7;
            // 
            // SaldoTextBoxCreateKonto
            // 
            this.SaldoTextBoxCreateKonto.Location = new System.Drawing.Point(42, 128);
            this.SaldoTextBoxCreateKonto.Name = "SaldoTextBoxCreateKonto";
            this.SaldoTextBoxCreateKonto.Size = new System.Drawing.Size(100, 22);
            this.SaldoTextBoxCreateKonto.TabIndex = 6;
            // 
            // KontoTypeIDTextBoxCreateKonto
            // 
            this.KontoTypeIDTextBoxCreateKonto.Location = new System.Drawing.Point(203, 55);
            this.KontoTypeIDTextBoxCreateKonto.Name = "KontoTypeIDTextBoxCreateKonto";
            this.KontoTypeIDTextBoxCreateKonto.Size = new System.Drawing.Size(100, 22);
            this.KontoTypeIDTextBoxCreateKonto.TabIndex = 5;
            // 
            // KundeNrTextBoxCreateKonto
            // 
            this.KundeNrTextBoxCreateKonto.Location = new System.Drawing.Point(39, 55);
            this.KundeNrTextBoxCreateKonto.Name = "KundeNrTextBoxCreateKonto";
            this.KundeNrTextBoxCreateKonto.Size = new System.Drawing.Size(100, 22);
            this.KundeNrTextBoxCreateKonto.TabIndex = 4;
            // 
            // DatoCreateKonto
            // 
            this.DatoCreateKonto.AutoSize = true;
            this.DatoCreateKonto.Location = new System.Drawing.Point(200, 108);
            this.DatoCreateKonto.Name = "DatoCreateKonto";
            this.DatoCreateKonto.Size = new System.Drawing.Size(38, 17);
            this.DatoCreateKonto.TabIndex = 3;
            this.DatoCreateKonto.Text = "Dato";
            // 
            // SaldoCreateKonto
            // 
            this.SaldoCreateKonto.AutoSize = true;
            this.SaldoCreateKonto.Location = new System.Drawing.Point(39, 108);
            this.SaldoCreateKonto.Name = "SaldoCreateKonto";
            this.SaldoCreateKonto.Size = new System.Drawing.Size(44, 17);
            this.SaldoCreateKonto.TabIndex = 2;
            this.SaldoCreateKonto.Text = "Saldo";
            // 
            // KontoTypeIdCreateKonto
            // 
            this.KontoTypeIdCreateKonto.AutoSize = true;
            this.KontoTypeIdCreateKonto.Location = new System.Drawing.Point(200, 30);
            this.KontoTypeIdCreateKonto.Name = "KontoTypeIdCreateKonto";
            this.KontoTypeIdCreateKonto.Size = new System.Drawing.Size(93, 17);
            this.KontoTypeIdCreateKonto.TabIndex = 1;
            this.KontoTypeIdCreateKonto.Text = "Konto type ID";
            // 
            // KundeNrCreateKonto
            // 
            this.KundeNrCreateKonto.AutoSize = true;
            this.KundeNrCreateKonto.Location = new System.Drawing.Point(39, 30);
            this.KundeNrCreateKonto.Name = "KundeNrCreateKonto";
            this.KundeNrCreateKonto.Size = new System.Drawing.Size(68, 17);
            this.KundeNrCreateKonto.TabIndex = 0;
            this.KundeNrCreateKonto.Text = "Kunde Nr";
            // 
            // CreateKonto
            // 
            this.CreateKonto.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.CreateKonto.Location = new System.Drawing.Point(12, 72);
            this.CreateKonto.Name = "CreateKonto";
            this.CreateKonto.Size = new System.Drawing.Size(108, 54);
            this.CreateKonto.TabIndex = 5;
            this.CreateKonto.Text = "Opret konto";
            this.CreateKonto.UseVisualStyleBackColor = true;
            this.CreateKonto.Click += new System.EventHandler(this.CreateKonto_Click);
            // 
            // SelectKunde
            // 
            this.SelectKunde.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.SelectKunde.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SelectKunde.Location = new System.Drawing.Point(12, 135);
            this.SelectKunde.Name = "SelectKunde";
            this.SelectKunde.Size = new System.Drawing.Size(108, 54);
            this.SelectKunde.TabIndex = 7;
            this.SelectKunde.Text = "Find kunde";
            this.SelectKunde.UseVisualStyleBackColor = true;
            this.SelectKunde.Click += new System.EventHandler(this.SelectKonto_Click);
            // 
            // SelectKontoPanel
            // 
            this.SelectKontoPanel.Controls.Add(this.dataGridView1);
            this.SelectKontoPanel.Controls.Add(this.FuldlisteFindKontoKnap);
            this.SelectKontoPanel.Controls.Add(this.FindKundeButton);
            this.SelectKontoPanel.Controls.Add(this.KundeNrSelectKontoKundeNr);
            this.SelectKontoPanel.Controls.Add(this.SelectKontoTextBoxSelectKonto);
            this.SelectKontoPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SelectKontoPanel.Location = new System.Drawing.Point(260, 20);
            this.SelectKontoPanel.Name = "SelectKontoPanel";
            this.SelectKontoPanel.Size = new System.Drawing.Size(710, 441);
            this.SelectKontoPanel.TabIndex = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 69);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(680, 364);
            this.dataGridView1.TabIndex = 9;
            // 
            // FuldlisteFindKontoKnap
            // 
            this.FuldlisteFindKontoKnap.Location = new System.Drawing.Point(266, 36);
            this.FuldlisteFindKontoKnap.Name = "FuldlisteFindKontoKnap";
            this.FuldlisteFindKontoKnap.Size = new System.Drawing.Size(75, 23);
            this.FuldlisteFindKontoKnap.TabIndex = 3;
            this.FuldlisteFindKontoKnap.Text = "Fuld liste";
            this.FuldlisteFindKontoKnap.UseVisualStyleBackColor = true;
            this.FuldlisteFindKontoKnap.Click += new System.EventHandler(this.FuldlisteFindKontoKnap_Click);
            // 
            // FindKundeButton
            // 
            this.FindKundeButton.Location = new System.Drawing.Point(171, 36);
            this.FindKundeButton.Name = "FindKundeButton";
            this.FindKundeButton.Size = new System.Drawing.Size(75, 23);
            this.FindKundeButton.TabIndex = 2;
            this.FindKundeButton.Text = "Find konto";
            this.FindKundeButton.UseVisualStyleBackColor = true;
            this.FindKundeButton.Click += new System.EventHandler(this.FindKundeButton_Click);
            // 
            // KundeNrSelectKontoKundeNr
            // 
            this.KundeNrSelectKontoKundeNr.AutoSize = true;
            this.KundeNrSelectKontoKundeNr.Location = new System.Drawing.Point(36, 13);
            this.KundeNrSelectKontoKundeNr.Name = "KundeNrSelectKontoKundeNr";
            this.KundeNrSelectKontoKundeNr.Size = new System.Drawing.Size(68, 17);
            this.KundeNrSelectKontoKundeNr.TabIndex = 1;
            this.KundeNrSelectKontoKundeNr.Text = "Kunde Nr";
            // 
            // SelectKontoTextBoxSelectKonto
            // 
            this.SelectKontoTextBoxSelectKonto.Location = new System.Drawing.Point(39, 33);
            this.SelectKontoTextBoxSelectKonto.Name = "SelectKontoTextBoxSelectKonto";
            this.SelectKontoTextBoxSelectKonto.Size = new System.Drawing.Size(100, 22);
            this.SelectKontoTextBoxSelectKonto.TabIndex = 0;
            // 
            // SletKontoKnap
            // 
            this.SletKontoKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.SletKontoKnap.Location = new System.Drawing.Point(127, 72);
            this.SletKontoKnap.Name = "SletKontoKnap";
            this.SletKontoKnap.Size = new System.Drawing.Size(109, 54);
            this.SletKontoKnap.TabIndex = 9;
            this.SletKontoKnap.Text = "Slet Konto/Genop konto";
            this.SletKontoKnap.UseVisualStyleBackColor = true;
            this.SletKontoKnap.Click += new System.EventHandler(this.SletKontoKnap_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.KontoNrGenopret);
            this.panel3.Controls.Add(this.KontoNrSlet);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.KontoNrTextBox);
            this.panel3.Location = new System.Drawing.Point(260, 20);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(710, 441);
            this.panel3.TabIndex = 10;
            // 
            // KontoNrGenopret
            // 
            this.KontoNrGenopret.Location = new System.Drawing.Point(200, 65);
            this.KontoNrGenopret.Name = "KontoNrGenopret";
            this.KontoNrGenopret.Size = new System.Drawing.Size(100, 23);
            this.KontoNrGenopret.TabIndex = 3;
            this.KontoNrGenopret.Text = "Genopret";
            this.KontoNrGenopret.UseVisualStyleBackColor = true;
            this.KontoNrGenopret.Click += new System.EventHandler(this.KontoNrGenopret_Click);
            // 
            // KontoNrSlet
            // 
            this.KontoNrSlet.Location = new System.Drawing.Point(200, 31);
            this.KontoNrSlet.Name = "KontoNrSlet";
            this.KontoNrSlet.Size = new System.Drawing.Size(100, 23);
            this.KontoNrSlet.TabIndex = 2;
            this.KontoNrSlet.Text = "Slet Konto";
            this.KontoNrSlet.UseVisualStyleBackColor = true;
            this.KontoNrSlet.Click += new System.EventHandler(this.KontoNrSlet_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Konto Nr";
            // 
            // KontoNrTextBox
            // 
            this.KontoNrTextBox.Location = new System.Drawing.Point(62, 32);
            this.KontoNrTextBox.Name = "KontoNrTextBox";
            this.KontoNrTextBox.Size = new System.Drawing.Size(100, 22);
            this.KontoNrTextBox.TabIndex = 0;
            // 
            // PosteringMenu
            // 
            this.PosteringMenu.Location = new System.Drawing.Point(128, 135);
            this.PosteringMenu.Name = "PosteringMenu";
            this.PosteringMenu.Size = new System.Drawing.Size(108, 54);
            this.PosteringMenu.TabIndex = 11;
            this.PosteringMenu.Text = "Postering";
            this.PosteringMenu.UseVisualStyleBackColor = true;
            this.PosteringMenu.Click += new System.EventHandler(this.PosteringMenu_Click);
            // 
            // PosteringMenuPanel1
            // 
            this.PosteringMenuPanel1.Controls.Add(this.label4);
            this.PosteringMenuPanel1.Controls.Add(this.PosteringsDecimalDecimal);
            this.PosteringMenuPanel1.Controls.Add(this.label3);
            this.PosteringMenuPanel1.Controls.Add(this.PosteringsDato);
            this.PosteringMenuPanel1.Controls.Add(this.PosteringMenuAccepterKnap);
            this.PosteringMenuPanel1.Controls.Add(this.PosteringMenuLabelBeløb);
            this.PosteringMenuPanel1.Controls.Add(this.PosteringIntInt);
            this.PosteringMenuPanel1.Location = new System.Drawing.Point(260, 20);
            this.PosteringMenuPanel1.Name = "PosteringMenuPanel1";
            this.PosteringMenuPanel1.Size = new System.Drawing.Size(710, 441);
            this.PosteringMenuPanel1.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Beløb";
            // 
            // PosteringsDecimalDecimal
            // 
            this.PosteringsDecimalDecimal.Location = new System.Drawing.Point(40, 179);
            this.PosteringsDecimalDecimal.Name = "PosteringsDecimalDecimal";
            this.PosteringsDecimalDecimal.Size = new System.Drawing.Size(126, 22);
            this.PosteringsDecimalDecimal.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Dato";
            // 
            // PosteringsDato
            // 
            this.PosteringsDato.Location = new System.Drawing.Point(40, 117);
            this.PosteringsDato.Name = "PosteringsDato";
            this.PosteringsDato.Size = new System.Drawing.Size(126, 22);
            this.PosteringsDato.TabIndex = 3;
            // 
            // PosteringMenuAccepterKnap
            // 
            this.PosteringMenuAccepterKnap.Location = new System.Drawing.Point(249, 36);
            this.PosteringMenuAccepterKnap.Name = "PosteringMenuAccepterKnap";
            this.PosteringMenuAccepterKnap.Size = new System.Drawing.Size(143, 51);
            this.PosteringMenuAccepterKnap.TabIndex = 2;
            this.PosteringMenuAccepterKnap.Text = "Accepter Postering";
            this.PosteringMenuAccepterKnap.UseVisualStyleBackColor = true;
            this.PosteringMenuAccepterKnap.Click += new System.EventHandler(this.PosteringMenuAccepterKnap_Click);
            // 
            // PosteringMenuLabelBeløb
            // 
            this.PosteringMenuLabelBeløb.AutoSize = true;
            this.PosteringMenuLabelBeløb.Location = new System.Drawing.Point(40, 30);
            this.PosteringMenuLabelBeløb.Name = "PosteringMenuLabelBeløb";
            this.PosteringMenuLabelBeløb.Size = new System.Drawing.Size(60, 17);
            this.PosteringMenuLabelBeløb.TabIndex = 1;
            this.PosteringMenuLabelBeløb.Text = "KontoNr";
            // 
            // PosteringIntInt
            // 
            this.PosteringIntInt.Location = new System.Drawing.Point(40, 53);
            this.PosteringIntInt.Name = "PosteringIntInt";
            this.PosteringIntInt.Size = new System.Drawing.Size(126, 22);
            this.PosteringIntInt.TabIndex = 0;
            // 
            // SelectKonto
            // 
            this.SelectKonto.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.SelectKonto.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SelectKonto.Location = new System.Drawing.Point(12, 195);
            this.SelectKonto.Name = "SelectKonto";
            this.SelectKonto.Size = new System.Drawing.Size(108, 54);
            this.SelectKonto.TabIndex = 13;
            this.SelectKonto.Text = "Find Konti";
            this.SelectKonto.UseVisualStyleBackColor = true;
            this.SelectKonto.Click += new System.EventHandler(this.SelectKonto_Click_1);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dataGridView2);
            this.panel4.Controls.Add(this.FindKontoFuldListeKnap);
            this.panel4.Controls.Add(this.FindKontoFindKnap);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.FindKontoKontoNr);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panel4.Location = new System.Drawing.Point(260, 20);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(710, 441);
            this.panel4.TabIndex = 14;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(9, 69);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(680, 364);
            this.dataGridView2.TabIndex = 9;
            // 
            // FindKontoFuldListeKnap
            // 
            this.FindKontoFuldListeKnap.Location = new System.Drawing.Point(266, 36);
            this.FindKontoFuldListeKnap.Name = "FindKontoFuldListeKnap";
            this.FindKontoFuldListeKnap.Size = new System.Drawing.Size(75, 23);
            this.FindKontoFuldListeKnap.TabIndex = 3;
            this.FindKontoFuldListeKnap.Text = "Fuld liste";
            this.FindKontoFuldListeKnap.UseVisualStyleBackColor = true;
            this.FindKontoFuldListeKnap.Click += new System.EventHandler(this.FindKontoFuldListeKnap_Click);
            // 
            // FindKontoFindKnap
            // 
            this.FindKontoFindKnap.Location = new System.Drawing.Point(171, 36);
            this.FindKontoFindKnap.Name = "FindKontoFindKnap";
            this.FindKontoFindKnap.Size = new System.Drawing.Size(75, 23);
            this.FindKontoFindKnap.TabIndex = 2;
            this.FindKontoFindKnap.Text = "Find konto";
            this.FindKontoFindKnap.UseVisualStyleBackColor = true;
            this.FindKontoFindKnap.Click += new System.EventHandler(this.FindKontoFindKnap_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Kunde Nr";
            // 
            // FindKontoKontoNr
            // 
            this.FindKontoKontoNr.Location = new System.Drawing.Point(39, 33);
            this.FindKontoKontoNr.Name = "FindKontoKontoNr";
            this.FindKontoKontoNr.Size = new System.Drawing.Size(100, 22);
            this.FindKontoKontoNr.TabIndex = 0;
            // 
            // FindTransaktionButton
            // 
            this.FindTransaktionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.FindTransaktionButton.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FindTransaktionButton.Location = new System.Drawing.Point(128, 195);
            this.FindTransaktionButton.Name = "FindTransaktionButton";
            this.FindTransaktionButton.Size = new System.Drawing.Size(108, 54);
            this.FindTransaktionButton.TabIndex = 15;
            this.FindTransaktionButton.Text = "Find Transaktioner";
            this.FindTransaktionButton.UseVisualStyleBackColor = true;
            this.FindTransaktionButton.Click += new System.EventHandler(this.FindTransaktionButton_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView3);
            this.panel5.Controls.Add(this.TransaktionsFindKnap);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.TransaktionTextBox);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panel5.Location = new System.Drawing.Point(260, 20);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(710, 441);
            this.panel5.TabIndex = 15;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(9, 69);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(680, 364);
            this.dataGridView3.TabIndex = 9;
            // 
            // TransaktionsFindKnap
            // 
            this.TransaktionsFindKnap.Location = new System.Drawing.Point(171, 33);
            this.TransaktionsFindKnap.Name = "TransaktionsFindKnap";
            this.TransaktionsFindKnap.Size = new System.Drawing.Size(75, 23);
            this.TransaktionsFindKnap.TabIndex = 2;
            this.TransaktionsFindKnap.Text = "Find konto";
            this.TransaktionsFindKnap.UseVisualStyleBackColor = true;
            this.TransaktionsFindKnap.Click += new System.EventHandler(this.TransaktionsFindKnap_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Konto Nr";
            // 
            // TransaktionTextBox
            // 
            this.TransaktionTextBox.Location = new System.Drawing.Point(39, 33);
            this.TransaktionTextBox.Name = "TransaktionTextBox";
            this.TransaktionTextBox.Size = new System.Drawing.Size(100, 22);
            this.TransaktionTextBox.TabIndex = 0;
            // 
            // UpdateKundeKnap
            // 
            this.UpdateKundeKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.UpdateKundeKnap.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.UpdateKundeKnap.Location = new System.Drawing.Point(12, 255);
            this.UpdateKundeKnap.Name = "UpdateKundeKnap";
            this.UpdateKundeKnap.Size = new System.Drawing.Size(108, 54);
            this.UpdateKundeKnap.TabIndex = 16;
            this.UpdateKundeKnap.Text = "Update kunde";
            this.UpdateKundeKnap.UseVisualStyleBackColor = true;
            this.UpdateKundeKnap.Click += new System.EventHandler(this.UpdateKundeKnap_Click);
            // 
            // UpdateKontoKnap
            // 
            this.UpdateKontoKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.UpdateKontoKnap.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.UpdateKontoKnap.Location = new System.Drawing.Point(127, 255);
            this.UpdateKontoKnap.Name = "UpdateKontoKnap";
            this.UpdateKontoKnap.Size = new System.Drawing.Size(108, 54);
            this.UpdateKontoKnap.TabIndex = 17;
            this.UpdateKontoKnap.Text = "Update konto";
            this.UpdateKontoKnap.UseVisualStyleBackColor = true;
            this.UpdateKontoKnap.Click += new System.EventHandler(this.UpdateKontoKnap_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.UpdateKundeKundeNr);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.UpdateKundeOk);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.UpdateKundLabelPostNr);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.UpdateKundeLabelEfternavn);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.UpdateKundeDato);
            this.panel6.Controls.Add(this.UpdateKundePostNr);
            this.panel6.Controls.Add(this.UpdateKundeAdresse);
            this.panel6.Controls.Add(this.UpdateKundeEfternavn);
            this.panel6.Controls.Add(this.UpdateKundeFornavn);
            this.panel6.Location = new System.Drawing.Point(257, 20);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(710, 441);
            this.panel6.TabIndex = 18;
            // 
            // UpdateKundeKundeNr
            // 
            this.UpdateKundeKundeNr.Location = new System.Drawing.Point(42, 33);
            this.UpdateKundeKundeNr.Name = "UpdateKundeKundeNr";
            this.UpdateKundeKundeNr.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundeKundeNr.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "KundeNr";
            // 
            // UpdateKundeOk
            // 
            this.UpdateKundeOk.Location = new System.Drawing.Point(139, 193);
            this.UpdateKundeOk.Name = "UpdateKundeOk";
            this.UpdateKundeOk.Size = new System.Drawing.Size(75, 23);
            this.UpdateKundeOk.TabIndex = 11;
            this.UpdateKundeOk.Text = "Ok";
            this.UpdateKundeOk.UseVisualStyleBackColor = true;
            this.UpdateKundeOk.Click += new System.EventHandler(this.UpdateKundeOk_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(199, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "Dato";
            // 
            // UpdateKundLabelPostNr
            // 
            this.UpdateKundLabelPostNr.AutoSize = true;
            this.UpdateKundLabelPostNr.Location = new System.Drawing.Point(201, 73);
            this.UpdateKundLabelPostNr.Name = "UpdateKundLabelPostNr";
            this.UpdateKundLabelPostNr.Size = new System.Drawing.Size(51, 17);
            this.UpdateKundLabelPostNr.TabIndex = 8;
            this.UpdateKundLabelPostNr.Text = "PostNr";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Adresse";
            // 
            // UpdateKundeLabelEfternavn
            // 
            this.UpdateKundeLabelEfternavn.AutoSize = true;
            this.UpdateKundeLabelEfternavn.Location = new System.Drawing.Point(201, 16);
            this.UpdateKundeLabelEfternavn.Name = "UpdateKundeLabelEfternavn";
            this.UpdateKundeLabelEfternavn.Size = new System.Drawing.Size(69, 17);
            this.UpdateKundeLabelEfternavn.TabIndex = 6;
            this.UpdateKundeLabelEfternavn.Text = "Efternavn";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Fornavn";
            // 
            // UpdateKundeDato
            // 
            this.UpdateKundeDato.Location = new System.Drawing.Point(198, 147);
            this.UpdateKundeDato.Name = "UpdateKundeDato";
            this.UpdateKundeDato.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundeDato.TabIndex = 4;
            // 
            // UpdateKundePostNr
            // 
            this.UpdateKundePostNr.Location = new System.Drawing.Point(198, 93);
            this.UpdateKundePostNr.Name = "UpdateKundePostNr";
            this.UpdateKundePostNr.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundePostNr.TabIndex = 3;
            // 
            // UpdateKundeAdresse
            // 
            this.UpdateKundeAdresse.Location = new System.Drawing.Point(42, 149);
            this.UpdateKundeAdresse.Name = "UpdateKundeAdresse";
            this.UpdateKundeAdresse.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundeAdresse.TabIndex = 2;
            // 
            // UpdateKundeEfternavn
            // 
            this.UpdateKundeEfternavn.Location = new System.Drawing.Point(198, 36);
            this.UpdateKundeEfternavn.Name = "UpdateKundeEfternavn";
            this.UpdateKundeEfternavn.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundeEfternavn.TabIndex = 1;
            // 
            // UpdateKundeFornavn
            // 
            this.UpdateKundeFornavn.Location = new System.Drawing.Point(42, 94);
            this.UpdateKundeFornavn.Name = "UpdateKundeFornavn";
            this.UpdateKundeFornavn.Size = new System.Drawing.Size(100, 22);
            this.UpdateKundeFornavn.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.UpdateKontoOk);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.label12);
            this.panel7.Controls.Add(this.label13);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.UpdateKontoSaldo);
            this.panel7.Controls.Add(this.UpdateKontoOprettelsesdato);
            this.panel7.Controls.Add(this.UpdateKontoAktiv);
            this.panel7.Controls.Add(this.UpdateKontoNr);
            this.panel7.Location = new System.Drawing.Point(257, 20);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(710, 441);
            this.panel7.TabIndex = 19;
            // 
            // UpdateKontoOk
            // 
            this.UpdateKontoOk.Location = new System.Drawing.Point(138, 140);
            this.UpdateKontoOk.Name = "UpdateKontoOk";
            this.UpdateKontoOk.Size = new System.Drawing.Size(75, 23);
            this.UpdateKontoOk.TabIndex = 10;
            this.UpdateKontoOk.Text = "Ok";
            this.UpdateKontoOk.UseVisualStyleBackColor = true;
            this.UpdateKontoOk.Click += new System.EventHandler(this.UpdateKontoOk_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(205, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Saldo";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "Oprettelsesdato";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(203, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 17);
            this.label13.TabIndex = 6;
            this.label13.Text = "Aktiv";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 17);
            this.label14.TabIndex = 5;
            this.label14.Text = "KontoNr";
            // 
            // UpdateKontoSaldo
            // 
            this.UpdateKontoSaldo.Location = new System.Drawing.Point(206, 89);
            this.UpdateKontoSaldo.Name = "UpdateKontoSaldo";
            this.UpdateKontoSaldo.Size = new System.Drawing.Size(100, 22);
            this.UpdateKontoSaldo.TabIndex = 3;
            // 
            // UpdateKontoOprettelsesdato
            // 
            this.UpdateKontoOprettelsesdato.Location = new System.Drawing.Point(45, 89);
            this.UpdateKontoOprettelsesdato.Name = "UpdateKontoOprettelsesdato";
            this.UpdateKontoOprettelsesdato.Size = new System.Drawing.Size(100, 22);
            this.UpdateKontoOprettelsesdato.TabIndex = 2;
            // 
            // UpdateKontoAktiv
            // 
            this.UpdateKontoAktiv.Location = new System.Drawing.Point(206, 32);
            this.UpdateKontoAktiv.Name = "UpdateKontoAktiv";
            this.UpdateKontoAktiv.Size = new System.Drawing.Size(100, 22);
            this.UpdateKontoAktiv.TabIndex = 1;
            // 
            // UpdateKontoNr
            // 
            this.UpdateKontoNr.Location = new System.Drawing.Point(45, 34);
            this.UpdateKontoNr.Name = "UpdateKontoNr";
            this.UpdateKontoNr.Size = new System.Drawing.Size(100, 22);
            this.UpdateKontoNr.TabIndex = 0;
            // 
            // UpdateKontypeKnap
            // 
            this.UpdateKontypeKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.7F);
            this.UpdateKontypeKnap.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.UpdateKontypeKnap.Location = new System.Drawing.Point(12, 315);
            this.UpdateKontypeKnap.Name = "UpdateKontypeKnap";
            this.UpdateKontypeKnap.Size = new System.Drawing.Size(108, 54);
            this.UpdateKontypeKnap.TabIndex = 20;
            this.UpdateKontypeKnap.Text = "Update Kontotype";
            this.UpdateKontypeKnap.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.UpdateKontypeKnap.UseVisualStyleBackColor = true;
            this.UpdateKontypeKnap.Click += new System.EventHandler(this.UpdateKontypeKnap_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.UpdateKontoTypeRentesats);
            this.panel8.Controls.Add(this.UpdateKontotypeKontotype);
            this.panel8.Controls.Add(this.UpdateKontotypeOk);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Location = new System.Drawing.Point(257, 20);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(710, 441);
            this.panel8.TabIndex = 21;
            // 
            // UpdateKontoTypeRentesats
            // 
            this.UpdateKontoTypeRentesats.Location = new System.Drawing.Point(234, 34);
            this.UpdateKontoTypeRentesats.Multiline = true;
            this.UpdateKontoTypeRentesats.Name = "UpdateKontoTypeRentesats";
            this.UpdateKontoTypeRentesats.Size = new System.Drawing.Size(121, 24);
            this.UpdateKontoTypeRentesats.TabIndex = 12;
            // 
            // UpdateKontotypeKontotype
            // 
            this.UpdateKontotypeKontotype.FormattingEnabled = true;
            this.UpdateKontotypeKontotype.Location = new System.Drawing.Point(48, 33);
            this.UpdateKontotypeKontotype.Name = "UpdateKontotypeKontotype";
            this.UpdateKontotypeKontotype.Size = new System.Drawing.Size(121, 24);
            this.UpdateKontotypeKontotype.TabIndex = 11;
            this.UpdateKontotypeKontotype.SelectedIndexChanged += new System.EventHandler(this.UpdateKontotypeKontotype_SelectedIndexChanged);
            // 
            // UpdateKontotypeOk
            // 
            this.UpdateKontotypeOk.Location = new System.Drawing.Point(159, 83);
            this.UpdateKontotypeOk.Name = "UpdateKontotypeOk";
            this.UpdateKontotypeOk.Size = new System.Drawing.Size(75, 23);
            this.UpdateKontotypeOk.TabIndex = 10;
            this.UpdateKontotypeOk.Text = "Ok";
            this.UpdateKontotypeOk.UseVisualStyleBackColor = true;
            this.UpdateKontotypeOk.Click += new System.EventHandler(this.UpdateKontotypeOk_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(231, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 17);
            this.label18.TabIndex = 6;
            this.label18.Text = "Rentesats";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(45, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 17);
            this.label19.TabIndex = 5;
            this.label19.Text = "Kontotype";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 468);
            this.Controls.Add(this.UpdateKontypeKnap);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.UpdateKontoKnap);
            this.Controls.Add(this.UpdateKundeKnap);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.FindTransaktionButton);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.SelectKonto);
            this.Controls.Add(this.PosteringMenuPanel1);
            this.Controls.Add(this.PosteringMenu);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.SletKontoKnap);
            this.Controls.Add(this.DeleteUser);
            this.Controls.Add(this.SelectKunde);
            this.Controls.Add(this.CreateKonto);
            this.Controls.Add(this.CreateUser);
            this.Controls.Add(this.SelectKontoPanel);
            this.Controls.Add(this.CreateKontoPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel8);
            this.Name = "Form1";
            this.Text = "Bank Program";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.CreateKontoPanel.ResumeLayout(false);
            this.CreateKontoPanel.PerformLayout();
            this.SelectKontoPanel.ResumeLayout(false);
            this.SelectKontoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.PosteringMenuPanel1.ResumeLayout(false);
            this.PosteringMenuPanel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CreateUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox EfternavnTextBoxCreateUser;
        private System.Windows.Forms.Label EfterNavnLabelCreateUser;
        private System.Windows.Forms.TextBox FornavnTextBoxCreateUser;
        private System.Windows.Forms.Label FornavnLabelCreateUser;
        private System.Windows.Forms.TextBox PostNrTextBoxCreateUser;
        private System.Windows.Forms.Label PostNrLabelCreateUser;
        private System.Windows.Forms.TextBox AdresseTextBoxCreateUser;
        private System.Windows.Forms.Label AdresseLabelCreateUser;
        private System.Windows.Forms.Button CReateUserButtonCreateUser;
        private System.Windows.Forms.TextBox DatoTextboxCreateUser;
        private System.Windows.Forms.Label DatoLabelCreateUser;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button DeleteUserButtonDeleteUser;
        private System.Windows.Forms.Button DeleteUser;
        private System.Windows.Forms.TextBox UserIdTextBoxDeleteUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel CreateKontoPanel;
        private System.Windows.Forms.TextBox DatoiTextBoxCreateKonto;
        private System.Windows.Forms.TextBox SaldoTextBoxCreateKonto;
        private System.Windows.Forms.TextBox KontoTypeIDTextBoxCreateKonto;
        private System.Windows.Forms.TextBox KundeNrTextBoxCreateKonto;
        private System.Windows.Forms.Label DatoCreateKonto;
        private System.Windows.Forms.Label SaldoCreateKonto;
        private System.Windows.Forms.Label KontoTypeIdCreateKonto;
        private System.Windows.Forms.Label KundeNrCreateKonto;
        private System.Windows.Forms.Button CreateKonto;
        private System.Windows.Forms.Button SelectKunde;
        private System.Windows.Forms.Panel SelectKontoPanel;
        private System.Windows.Forms.Label KundeNrSelectKontoKundeNr;
        private System.Windows.Forms.TextBox SelectKontoTextBoxSelectKonto;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button OpretKontoButton;
        private System.Windows.Forms.Button FindKundeButton;
        private System.Windows.Forms.Button GenopretButtonDeleteUser;
        private System.Windows.Forms.Button FuldlisteFindKontoKnap;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SletKontoKnap;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button KontoNrGenopret;
        private System.Windows.Forms.Button KontoNrSlet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox KontoNrTextBox;
        private System.Windows.Forms.Button PosteringMenu;
        private System.Windows.Forms.Panel PosteringMenuPanel1;
        private System.Windows.Forms.Button PosteringMenuAccepterKnap;
        private System.Windows.Forms.Label PosteringMenuLabelBeløb;
        private System.Windows.Forms.TextBox PosteringIntInt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PosteringsDecimalDecimal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PosteringsDato;
        private System.Windows.Forms.Button SelectKonto;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button FindKontoFuldListeKnap;
        private System.Windows.Forms.Button FindKontoFindKnap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox FindKontoKontoNr;
        private System.Windows.Forms.Button FindTransaktionButton;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button TransaktionsFindKnap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TransaktionTextBox;
        private System.Windows.Forms.Button UpdateKundeKnap;
        private System.Windows.Forms.Button UpdateKontoKnap;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button UpdateKundeOk;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label UpdateKundLabelPostNr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label UpdateKundeLabelEfternavn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox UpdateKundeDato;
        private System.Windows.Forms.TextBox UpdateKundePostNr;
        private System.Windows.Forms.TextBox UpdateKundeAdresse;
        private System.Windows.Forms.TextBox UpdateKundeEfternavn;
        private System.Windows.Forms.TextBox UpdateKundeFornavn;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button UpdateKontoOk;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox UpdateKontoSaldo;
        private System.Windows.Forms.TextBox UpdateKontoOprettelsesdato;
        private System.Windows.Forms.TextBox UpdateKontoAktiv;
        private System.Windows.Forms.TextBox UpdateKontoNr;
        private System.Windows.Forms.Button UpdateKontypeKnap;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button UpdateKontotypeOk;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox UpdateKontoTypeRentesats;
        private System.Windows.Forms.ComboBox UpdateKontotypeKontotype;
        private System.Windows.Forms.TextBox UpdateKundeKundeNr;
        private System.Windows.Forms.Label label8;
    }
}

