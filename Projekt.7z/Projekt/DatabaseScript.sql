IF exists(SELECT * FROM sys.Databases WHERE NAME = 'BankDB')
BEGIN
	USE MASTER
	DROP DATABASE BankDB
END
GO

CREATE DATABASE BankDB
GO
USE BankDB
GO

CREATE TABLE [Postnummer-by]
(
	PostNr INT PRIMARY KEY,
	ByNavn NVARCHAR(100) NOT NULL
)

CREATE TABLE Kunde
(
   KundeNr INT PRIMARY KEY IDENTITY,
   Fornavn NVARCHAR(50) NOT NULL,
   Efternavn NVARCHAR(50) NOT NULL,
   Adresse NVARCHAR(50) NOT NULL,
   FK_PostNr INT NOT NULL foreign key references [Postnummer-by](PostNr),
   Kunde_Oprettelsesdato DATE NOT NULL CHECK (Kunde_Oprettelsesdato <= GetDate()),
   [Kunde_Aktiv] BIT NOT NULL
)

CREATE TABLE Kontotype
(
	ID INT PRIMARY KEY,
	KontoType NVARCHAR(20) NOT NULL,
	Rente DECIMAL(4,2) NOT NULL
)

CREATE TABLE Konto
(
   KontoNr INT PRIMARY KEY IDENTITY,
   FK_KundeNr INT NOT NULL foreign key references Kunde(KundeNr),
   FK_KontoTypeID INT NOT NULL foreign key references Kontotype(ID),
   Saldo DECIMAL (19,2) NOT NULL,
   Konto_Oprettelsesdato DATE NOT NULL CHECK (Konto_Oprettelsesdato <= GetDate()),
   Konto_Aktiv BIT NOT NULL
)

CREATE TABLE Transaktioner
(
	TransaktionsID INT PRIMARY KEY IDENTITY,
	Bel�b Decimal (19,2) NOT NULL,
	FK_KontoNr INT NOT NULL foreign key references Konto(KontoNr),
	Dato DATE NOT NULL 
	CHECK (Dato <= GetDate())
)
GO

Create Trigger Opdater_Saldo
On Transaktioner
After INSERT
AS
	Declare @Post decimal (19,2)
	Declare @KontoNr int
	Select @Post = Bel�b, @KontoNr = FK_KontoNr 
	From Transaktioner
	Update Konto
	Set Saldo = Saldo + @Post
	Where KontoNr = @KontoNr
Go

-- N�r Kunde deaktiveres, deaktiveres alle kundens konti ???
create trigger DeaktiverKonti
on Kunde
after update
as 
	declare @KundeKundeNr int
	select @KundeKundeNr = KundeNr
	from inserted where Kunde_Aktiv = 0
	update Konto 
	set Konto_Aktiv = 0 
	where FK_KundeNr = @KundeKundeNr
go

BULK
INSERT [Postnummer-by]
FROM 'C:\Users\Tec\Desktop\postnummer-by.csv'
WITH ( FIELDTERMINATOR = ';', ROWTERMINATOR ='\n')


INSERT INTO Kunde
VALUES
('Lars', 'Larsen', 'Ballerup Telegrafvej 1', 2750, '2018-01-16', 1),
('Simon', 'Simonsen', 'Simonsvej', 2000, '2016-06-16', 1),
('Rasmus', 'Rasmussen', 'H�rsholm', 2970, '2018-01-16', 1),
('Alex', 'Alexsen', 'Ballerup Telegrafvej 1', 2750, '2018-01-16', 1),
('S�ren', 'S�rensen', 'Bredek�rs v�nge 59', 2635, '2014-02-01', 1),
('Jason', 'Jasonsen', 'Hiller�dgade 88', 2200, '2010-07-23', 0)
go

INSERT INTO Kontotype
VALUES 
(1,'L�N', 0.5),
(2,'OPSARING', 1),
(3,'B�RNEOPSARING', 0.85),
(4,'L�NKONTO', 0.5),
(5,'KONTOKONTO',0.5),
(6, 'AKTIEKONTO',0.4)
go

INSERT INTO Konto(FK_KundeNr,FK_KontoTypeID,Saldo,Konto_Oprettelsesdato, Konto_Aktiv)
VALUES
(1, 1, 0, '2018-01-16', 1),
(2, 3, 2, '2017-06-16', 1),
(1, 4, -5000000, '2018-01-16', 1),
(2, 5, 1, '2018-01-16', 1),
(1, 2, 0.00001, '2014-02-01', 1),
(2, 6, 1000000, '2010-07-23', 1)
go