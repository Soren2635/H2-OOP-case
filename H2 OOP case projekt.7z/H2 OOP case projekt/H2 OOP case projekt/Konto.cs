﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace H2SQLTest
{
    class Konto
    {
        public static SqlConnection connection = new SqlConnection("Trusted_Connection = true; Server = localhost; Database = BankDB; Connection Timeout = 30");

        static Konto()
        {
            connection.Open();
        }

        public static void addKonto(int FK_KundeNr, int FK_KontoTypeID, decimal Saldo, string Oprettelsesdato)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Konto(FK_KundeNr, FK_KontoTypeID, Saldo, Konto_Oprettelsesdato, Konto_Aktiv) values('" + FK_KundeNr + "', '" + FK_KontoTypeID + "', '" + Saldo + "', '" + Oprettelsesdato + "',1);", connection);
            cmd.ExecuteNonQuery();


        } // Opret_Konto

        public static SqlDataAdapter selectKonto(int i)
        {
            string command = ("SELECT Kunde.KundeNr, Kunde.Efternavn, Konto.KontoNr, Konto.Konto_Oprettelsesdato, Konto.Saldo, Konto.Konto_Aktiv, Kontotype.KontoType, Kontotype.Rente FROM Kunde JOIN Konto ON Kunde.KundeNr = Konto.FK_KundeNr JOIN Kontotype ON dbo.Kontotype.ID = Konto.FK_KontoTypeID WHERE KundeNr = " + i);
            return (new SqlDataAdapter(command, connection));

            
        } // Vis enkelt konto

        public static SqlDataAdapter selectalleKonto()
        {
            string command = ("SELECT * FROM Kunde JOIN Konto ON Kunde.KundeNr = Konto.FK_KundeNr JOIN Kontotype ON dbo.Kontotype.ID = Konto.FK_KontoTypeID");
            return (new SqlDataAdapter(command, connection));
        } // Vis enkelt konto

        /// <summary>
        /// Angiver om en konto skal være aktiv eller inaktiv
        /// </summary>
        /// <param name="active">Kontoen er inaktiv, hvis 0. Kontoen er aktiv, hvis 1.</param>
        /// <param name="kontoNr">kontoNr angiver den konto, der ændres 'aktiv-tilstand' for.</param>
        public static void AktiveringKonto(int active, string kontoNr)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Konto SET Konto_Aktiv = " + active + " WHERE KontoNr = " + kontoNr , connection);
            cmd.ExecuteNonQuery();
        }

        public static void Update_Konto(decimal Saldo, string Oprettelsesdato, int Aktiv,  int KundeNr)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Konto Set Saldo = " + Saldo + ", Konto_Oprettelsesdato = '" + Oprettelsesdato + "', Konto_Aktiv = " + Aktiv +  "WHERE KontoNr = " + KundeNr, connection);
            cmd.ExecuteNonQuery();
        } // Opdater konto information
    }
}