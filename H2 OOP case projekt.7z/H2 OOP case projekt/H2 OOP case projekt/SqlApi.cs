﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H2_OOP_case_projekt
{
    static class SqlApi
    {
        public static SqlConnection connection = new SqlConnection("Trusted_Connection = true; Server = localhost; Database = BankDB; Connection Timeout = 30");

        static SqlApi()
        {
            connection.Open();
        }

        public static SqlDataAdapter selectTrans(int i)
        {
            string command = ("SELECT Kunde.KundeNr, Kunde.Efternavn, Konto.KontoNr, Transaktioner.TransaktionsID, Transaktioner.Beløb, Transaktioner.Dato FROM Transaktioner Join Konto ON Transaktioner.FK_KontoNr = Konto.KontoNr JOIN Kunde ON Konto.FK_KundeNr = KundeNr WHERE Konto.KontoNr = " + i);
            return (new SqlDataAdapter(command, connection));

        } // Vis transaktioner

        
        public static void retRente(decimal nyRente, int ID)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Kontotype SET rente = " + nyRente + "WHERE ID = " + ID, connection);
            cmd.ExecuteNonQuery();


        } // Ret rentesats

        public static void Postering (string Beløb, int KundeNr, string Dato)
        {
            SqlCommand cmd = new SqlCommand("Insert Into Transaktioner(Beløb, FK_KontoNr, Dato)Values(" + Beløb + "," + KundeNr + ",'" + Dato + "')", connection);
            cmd.ExecuteNonQuery();
        } // Postering

        public static SqlDataReader returnReader()
        {
            SqlDataReader reader = new SqlCommand("select ID, KontoType from Kontotype", connection).ExecuteReader();
            return reader;
        }

    }
}
