﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H2SQLTest;
using System.Data.SqlClient;

namespace H2_OOP_case_projekt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            CreateKontoPanel.Visible = false;
            panel1.Visible = false;
            panel2.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
            FillKontotypeDropdown();

        }

        //Menu knapper
        private void CreateUser_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            CreateKontoPanel.Visible = false;
            panel1.Visible = true;
            panel2.Visible = false;
            SelectKontoPanel.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;

            DatoTextboxCreateUser.Text = DateTime.Today.Date.ToString("yyyy-MM-dd");
        }
        private void DeleteUser_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            CreateKontoPanel.Visible = false;
            panel2.Visible = true;
            panel1.Visible = false;
            SelectKontoPanel.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }
        private void CreateKonto_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel2.Visible = false;
            panel1.Visible = false;
            SelectKontoPanel.Visible = false;
            CreateKontoPanel.Visible = true;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }

        private void SletKontoKnap_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            panel2.Visible = false;
            panel1.Visible = false;
            SelectKontoPanel.Visible = false;
            CreateKontoPanel.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }


        private void OpretKontoButton_Click(object sender, EventArgs e)
        {
            string Dato;
            int KundeNr, KontoTypeId;
            decimal Saldo;
            KundeNr = Convert.ToInt32(KundeNrTextBoxCreateKonto.Text);
            KontoTypeId = Convert.ToInt32(KontoTypeIDTextBoxCreateKonto.Text);
            Saldo = Convert.ToDecimal(SaldoTextBoxCreateKonto.Text);
            Dato = DatoiTextBoxCreateKonto.Text;
            Konto.addKonto(KundeNr, KontoTypeId, Saldo, Dato);


            MessageBox.Show("Konto oprettet");

        }

        private void SelectKonto_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = true;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }
        private void PosteringMenu_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = true;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }

        private void SelectKonto_Click_1(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = true;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;

        }

        private void FindTransaktionButton_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = true;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
        }

        private void UpdateKundeKnap_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = true;
            panel7.Visible = false;
            panel8.Visible = false;
        }

        private void UpdateKontoKnap_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = true;
            panel8.Visible = false;
        }
        private void UpdateKontypeKnap_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = false;
            CreateKontoPanel.Visible = false;
            SelectKontoPanel.Visible = false;
            panel3.Visible = false;
            PosteringMenuPanel1.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = true;
        }

        //Små knapper 



        private void PosteringMenuAccepterKnap_Click(object sender, EventArgs e)
        {
            //string PosteringsDecimal = PosteringsDecimalDecimal.Text;
            decimal PosteringsDecimal = Convert.ToDecimal(PosteringsDecimalDecimal.Text);
            int PosteringsInt = Convert.ToInt32(PosteringIntInt.Text);
            string PosteringsString = Convert.ToString(PosteringsDato.Text);
            string tempstring = PosteringsDecimal.ToString();

            tempstring = tempstring.Replace(",", ".");

            SqlApi.Postering(tempstring, PosteringsInt, PosteringsString);
            MessageBox.Show("Done");
        }

        private void FindKundeButton_Click(object sender, EventArgs e)
        {
            int KundeNr;

            KundeNr = Convert.ToInt32(SelectKontoTextBoxSelectKonto.Text);

            SqlDataAdapter dataadapter = Kunde.ListKunde_DA(KundeNr);
            DataSet ds = new DataSet();
            dataadapter.Fill(ds, "Kunde_table");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Kunde_table";
        }

        private void CReateUserButtonCreateUser_Click(object sender, EventArgs e)
        {
            string Fornavn, Efternavn, Adresse, Dato;
            int PostNr;

            Fornavn = FornavnTextBoxCreateUser.Text;
            Efternavn = EfternavnTextBoxCreateUser.Text;
            Adresse = AdresseTextBoxCreateUser.Text;
            PostNr = Convert.ToInt32(PostNrTextBoxCreateUser.Text);
            Dato = DatoTextboxCreateUser.Text;

            Kunde.Opret_Kunde(Fornavn, Efternavn, Adresse, PostNr, Dato);

            MessageBox.Show("Bruger oprettet");
        }

        private void DeleteUserButton_Click(object sender, EventArgs e)
        {
            Kunde.AktiveringKunde(0, UserIdTextBoxDeleteUser.Text);
        }

        private void GenopretButtonDeleteUser_Click(object sender, EventArgs e)
        {

            Kunde.AktiveringKunde(1, UserIdTextBoxDeleteUser.Text);
        }

        private void FuldlisteFindKontoKnap_Click(object sender, EventArgs e)
        {
            SqlDataAdapter dataadapter = Kunde.KundeListe_DA();
            DataSet ds = new DataSet();
            dataadapter.Fill(ds, "Kunde_table");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Kunde_table";
        }

        private void KontoNrSlet_Click(object sender, EventArgs e)
        {
            Konto.AktiveringKonto(0, KontoNrTextBox.Text);
        }

        private void KontoNrGenopret_Click(object sender, EventArgs e)
        {
            Konto.AktiveringKonto(1, KontoNrTextBox.Text);
        }

        private void FindKontoFindKnap_Click(object sender, EventArgs e)
        {
            int KontoNr = Convert.ToInt32(FindKontoKontoNr.Text);

            SqlDataAdapter dataadapter2 = Konto.selectKonto(KontoNr);
            DataSet ds = new DataSet();
            dataadapter2.Fill(ds, "Kunde_table");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "Kunde_table";
        }

        private void FindKontoFuldListeKnap_Click(object sender, EventArgs e)
        {
            SqlDataAdapter dataadapter2 = Konto.selectalleKonto();
            DataSet ds = new DataSet();
            dataadapter2.Fill(ds, "Kunde_table");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "Kunde_table";
        }

        private void TransaktionsFindKnap_Click(object sender, EventArgs e)
        {
            SqlDataAdapter dataadapter = SqlApi.selectTrans(Convert.ToInt32(TransaktionTextBox.Text));
            DataSet ds = new DataSet();
            dataadapter.Fill(ds, "transaktion_table");
            dataGridView3.DataSource = ds;
            dataGridView3.DataMember = "transaktion_table";
        }

        private void UpdateKundeOk_Click(object sender, EventArgs e)
        {
            string Fornavn, Efternavn, Adresse, Dato;
            int KundeNr, PostNr;

            KundeNr = Convert.ToInt32(UpdateKundeKundeNr.Text);
            Fornavn = UpdateKundeFornavn.Text;
            Efternavn = UpdateKundeEfternavn.Text;
            Adresse = UpdateKundeAdresse.Text;
            PostNr = Convert.ToInt32(UpdateKundePostNr.Text);
            Dato = UpdateKundeDato.Text;

            Kunde.Update_Kunde(Fornavn, Efternavn, Adresse, PostNr, Dato, KundeNr);
            MessageBox.Show("Bruger rettet");
        }

        private void UpdateKontoOk_Click(object sender, EventArgs e)
        {
            string Oprettelsesdato;
            int Aktiv, KontoNr;
            decimal Saldo;

            Saldo = Convert.ToInt32(UpdateKontoSaldo.Text);
            Oprettelsesdato = UpdateKontoOprettelsesdato.Text;
            Aktiv = Convert.ToInt32(UpdateKontoAktiv.Text);
            KontoNr = Convert.ToInt32(UpdateKontoNr.Text);

            Konto.Update_Konto(Saldo, Oprettelsesdato, Aktiv, KontoNr);
            MessageBox.Show("Konto rettet");
        }

        private void UpdateKontotypeOk_Click(object sender, EventArgs e)
        {
            decimal nyRente;
            nyRente = Convert.ToDecimal(UpdateKontoTypeRentesats.Text);

            SqlDataReader reader = SqlApi.returnReader();
            List<test> Kontotyper = new List<test>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Kontotyper.Add(new test(reader.GetInt32(0), reader.GetString(1)));
                }
            }
            reader.Close();

            foreach (var kontoType in Kontotyper)
            {
                if ( UpdateKontotypeKontotype.SelectedItem.ToString() == kontoType.kontoTypeName)
                {
                    SqlApi.retRente(nyRente, kontoType.ID);
                }
            }

            //SqlApi.retRente(nyRente, );
        }

        private class test
        {
            public int ID { get; set; }
            public string kontoTypeName { get; set; }

            public test(int ID, string kontoTypeName)
            {
                this.kontoTypeName = kontoTypeName;
                this.ID = ID;
            }
        }

        public void FillKontotypeDropdown()
        {
            SqlDataReader reader = SqlApi.returnReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    UpdateKontotypeKontotype.Items.Add(reader.GetString(1));
                    //UpdateKontotypeKontotype.Items.Add((new test(reader.GetInt32(0), reader.GetString(1))));
                }
            }
            reader.Close();
        }

        private void UpdateKontotypeKontotype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
