﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using H2_OOP_case_projekt;

namespace H2SQLTest
{
    class Kunde
    {
        // Connection til database
        public static SqlConnection connection = new SqlConnection("Trusted_Connection = true; Server = localhost; Database = BankDB; Connection Timeout = 30");

        
        static Kunde()
        {
            connection.Open();
        } // constructor oprettes når objektet kaldes

        // Fuld kunde list
        public static SqlDataAdapter KundeListe_DA()
        {
            return (new SqlDataAdapter("SELECT * FROM Kunde", connection));
        }

        public static SqlDataAdapter ListKunde_DA(int KundeNr)
        {
            return (new SqlDataAdapter("SELECT *  FROM Kunde where KundeNr = " + KundeNr, connection));
        } // find enkelt kunde

        public static void Opret_Kunde(string Fornavn, string Efternavn, string Adresse, int FK_PostNr, string Oprettelsesdato)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Kunde(Fornavn, Efternavn, Adresse, FK_PostNr, Kunde_Oprettelsesdato, Kunde_Aktiv) values('" + Fornavn + "', '" + Efternavn + "', '" + Adresse + "', '" + FK_PostNr + "', '" + Oprettelsesdato + "',1);", connection);
            cmd.ExecuteNonQuery();
        }// Opret kunde

        public static void AktiveringKunde(int active, string KundeNr)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Kunde SET Kunde_Aktiv = " + active + " WHERE KundeNr = " + KundeNr, connection);
            cmd.ExecuteNonQuery();
        } // Aktivere / Deaktivere kunde

        public static void Update_Kunde(string Fornavn, string Efternavn, string Adresse, int FK_PostNr, string Oprettelsesdato, int KundeNr)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Kunde SET Fornavn = '" + Fornavn + "', Efternavn = '" + Efternavn + "', Adresse = '" + Adresse + "', FK_PostNr = '" + FK_PostNr + "', Kunde_Oprettelsesdato = '" + Oprettelsesdato + "' WHERE KundeNr = " + KundeNr, connection);
            cmd.ExecuteNonQuery();
        } // Opdater kunde information

    }
}