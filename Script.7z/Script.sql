IF exists(SELECT * FROM sys.Databases WHERE NAME = 'BankDB')
BEGIN
	USE MASTER
	DROP DATABASE BankDB
END
GO

CREATE DATABASE BankDB
GO
USE BankDB
GO

CREATE TABLE [Postnummer-by]
(
	PostNr INT PRIMARY KEY,
	ByNavn NVARCHAR(100) NOT NULL
)

CREATE TABLE Kunde
(
   KundeNr INT PRIMARY KEY IDENTITY,
   Fornavn NVARCHAR(50) NOT NULL,
   Efternavn NVARCHAR(50) NOT NULL,
   Adresse NVARCHAR(50) NOT NULL,
   FK_PostNr INT NOT NULL foreign key references [Postnummer-by](PostNr),
   Kunde_Oprettelsesdato DATE NOT NULL CHECK (Kunde_Oprettelsesdato <= GetDate()),
   [Kunde_Aktiv] BIT NOT NULL
)

--CREATE TABLE KundeSlettet
--(
--   KundeNr INT,
--   Fornavn NVARCHAR(50) NOT NULL,
--   Efternavn NVARCHAR(50) NOT NULL,
--   Adresse NVARCHAR(50) NOT NULL,
--   FK_PostNr INT NOT NULL,
--   Kunde_Oprettelsesdato DATE NOT NULL
--   CHECK (Kunde_Oprettelsesdato <= GetDate())
--)

CREATE TABLE Kontotype
(
	ID INT PRIMARY KEY,
	KontoType NVARCHAR(20) NOT NULL,
	Rente DECIMAL(4,2) NOT NULL
)

CREATE TABLE Konto
(
   KontoNr INT PRIMARY KEY IDENTITY,
   FK_KundeNr INT NOT NULL foreign key references Kunde(KundeNr),
   FK_KontoTypeID INT NOT NULL foreign key references Kontotype(ID),
   Saldo DECIMAL (19,2) NOT NULL,
   Konto_Oprettelsesdato DATE NOT NULL CHECK (Konto_Oprettelsesdato <= GetDate()),
   Konto_Aktiv BIT NOT NULL
)

--CREATE TABLE KontoSlettet
--(
--   KontoNr INT,
--   FK_KundeNr INT NOT NULL,
--   FK_KontoTypeID INT NOT NULL,
--   Saldo DECIMAL (19,2) NOT NULL,
--   Konto_Oprettelsesdato DATE NOT NULL 
--   CHECK (Konto_Oprettelsesdato <= GetDate())
--)


CREATE TABLE Transaktioner
(
	TransaktionsID INT PRIMARY KEY IDENTITY,
	Bel�b Decimal (19,2) NOT NULL,
	FK_KontoNr INT NOT NULL foreign key references Konto(KontoNr),
	Dato DATE NOT NULL 
	CHECK (Dato <= GetDate())
)
GO

Create Trigger Opdater_Saldo
On Transaktioner
After INSERT
AS
	Declare @Post decimal (19,2)
	Declare @KontoNr int
	Select @Post = Bel�b, @KontoNr = FK_KontoNr 
	From Transaktioner
	Update Konto
	Set Saldo = Saldo + @Post
	Where KontoNr = @KontoNr
Go

-- N�r Kunde deaktiveres, deaktiveres alle kundens konti ???
--CREATE Trigger DeaktiverKonti
--ON Konto
--AFTER UPDATE
--AS	
	--DECLARE @KundeAktiv bit
	--DECLARE @KundeKundeNr int
	--SELECT @KundeAktiv = Kunde.Aktiv, @KundeKundeNr = Kunde.KundeNr
	--FROM Kunde
	
--	UPDATE Konto
--	SET Konto_Aktiv = 0
--	WHERE @KundeAktiv = 0 AND @KundeKundeNr = FK_KundeNr
----GO
go

create trigger DeaktiverKonti
on Kunde
after update
as 
	declare @KundeKundeNr int
	select @KundeKundeNr = KundeNr
	from inserted where Kunde_Aktiv = 0
	update Konto 
	set Konto_Aktiv = 0 
	where FK_KundeNr = @KundeKundeNr
go

select * from Kunde where KundeNr = 2
select * from Konto where FK_KundeNr = 2

update Kunde 
set Kunde_Aktiv = 0 where KundeNr = 1
--DECLARE @KundeAktiv bit
--DECLARE @KundeNr int
--SELECT @KundeAktiv = Kunde.Kunde_Aktiv, @KundeNr = Kunde.KundeNr
--FROM Kunde
--go

--UPDATE Konto 
--Set Konto.Konto_Aktiv = 0 
--Where @KundeAktiv = 0 AND @KundeNr = 2;
--go
	

BULK
INSERT [Postnummer-by]
FROM 'C:\Users\Tec\Desktop\postnummer-by.csv'
WITH ( FIELDTERMINATOR = ';', ROWTERMINATOR ='\n')


INSERT INTO Kunde
VALUES
('Lars', 'Larsen', 'Ballerup Telegrafvej 1', 2750, '2018-01-16', 1),
('Simon', 'Simonsen', 'Simonsvej', 2000, '2016-06-16', 1),
('Rasmus', 'Rasmussen', 'H�rsholm', 2970, '2018-01-16', 1),
('Alex', 'Alexsen', 'Ballerup Telegrafvej 1', 2750, '2018-01-16', 1),
('S�ren', 'S�rensen', 'Bredek�rs v�nge 59', 2635, '2014-02-01', 1),
('Jason', 'Jasonsen', 'Hiller�dgade 88', 2200, '2010-07-23', 0)
go

INSERT INTO Kontotype
VALUES 
(1,'L�N', 0.5),
(2,'OPSARING', 1),
(3,'B�RNEOPSARING', 0.85),
(4,'L�NKONTO', 0.5),
(5,'KONTOKONTO',0.5),
(6, 'AKTIEKONTO',0.4)
go

INSERT INTO Konto(FK_KundeNr,FK_KontoTypeID,Saldo,Konto_Oprettelsesdato, Konto_Aktiv)
VALUES
(1, 1, 0, '2018-01-16', 1),
(2, 3, 2, '2017-06-16', 1),
(1, 4, -5000000, '2018-01-16', 1),
(2, 5, 1, '2018-01-16', 1),
(1, 2, 0.00001, '2014-02-01', 1),
(2, 6, 1000000, '2010-07-23', 1)
go



--SELECT * FROM [Postnummer-by]
--SELECT * FROM Kunde
--SELECT * FROM KundeSlettet


--insert into KundeSlettet select * from Kunde Where KundeNr = 3; delete from Kunde where KundeNr = 3;
--insert into Kunde select Fornavn,Efternavn,Adresse,FK_PostNr,Oprettelsesdato from KundeSlettet Where KundeNr = 5; delete from KundeSlettet where KundeNr = 5;
/*
select * from Kunde order by Efternavn asc;

Select Kunde.*, Konto.KontoNr,Konto.Saldo, Konto.Konto_Oprettelsesdato,KontoType.Rente,KontoType.KontoType
FROM Kunde
	join Konto on Konto.FK_KundeNr = Kunde.KundeNr
	join Kontotype on Kontotype.ID = konto.FK_KontoTypeID
where KundeNr = '1';

select * from Konto
Select * from KontoSlettet

UPDATE Kunde 
SET Fornavn = '', Efternavn = '', Adresse = '', FK_PostNr = 
WHERE KundeNr = 


select * from Transaktioner
go


select * from Konto
where KontoNr = 6

Insert Into Transaktioner(Bel�b, FK_KontoNr, Dato)
Values (100000, 6, '2018-01-01')


select * from Kunde
select * from Transaktioner


select * from Kunde
where KundeNr = 6

SELECT Kunde.KundeNr, Kunde.Efternavn, Konto.KontoNr, Konto.Oprettelsesdato, Konto.Saldo, Kontotype.KontoType, Kontotype.Rente FROM Kunde JOIN Konto ON Kunde.KundeNr = Konto.FK_KundeNr JOIN Kontotype ON dbo.Kontotype.ID = Konto.FK_KontoTypeID WHERE KontoNr = " + i
*/
/*
SELECT Kunde.KundeNr, Kunde.Efternavn, Konto.KontoNr, Transaktioner.TransaktionsID, Transaktioner.Bel�b, Transaktioner.Dato
FROM Transaktioner
	Join Konto ON Transaktioner.FK_KontoNr = Konto.KontoNr
	JOIN Kunde ON Konto.FK_KundeNr = KundeNr 
WHERE Konto.KontoNr = 2
*/
--UPDATE Konto SET Aktiv = 0 WHERE KontoNr = 4
--UPDATE Kunde SET Aktiv = " + active + " WHERE KundeNr = " + KundeNr , connection




UPDATE Kunde SET Fornavn = 'Albert', Efternavn = 'Pik', Adresse = 'KneeGrowz', FK_PostNr = 2000
 WHERE KundeNr = 2;
          